items = {
	Items.Hay: 999999999999,
	Items.Weird_Substance: 999999999999,
}

simulate("f5", Unlocks, items, {}, 0, 100)