def plant_grass():
	if get_ground_type() != Grounds.Grassland:
		till()
	#plant(Entities.Grass)
		
def plant_bush():
	if get_ground_type() != Grounds.Grassland:
		till()
	plant(Entities.Bush)
	
def plant_carrot():
	if get_ground_type() == Grounds.Grassland:
		till()
	plant(Entities.Carrot)
	
def plant_tree():
	if get_ground_type() != Grounds.Grassland:
		till()
	plant(Entities.Tree)
	
def plant_cactus():
	if get_ground_type() == Grounds.Grassland:
		till()
	plant(Entities.Cactus)

def plant_pumpkin():
	if get_ground_type() == Grounds.Grassland:
		till()
	plant(Entities.Pumpkin)

def plant_sunflower():
	if get_ground_type() == Grounds.Grassland:
		till()
	plant(Entities.Sunflower)

def get_instructions(entity):
	table = {
		Entities.Grass: plant_grass, 
		Entities.Bush: plant_bush,
		Entities.Carrot: plant_carrot,
		Entities.Tree: plant_tree,
		Entities.Cactus: plant_cactus,
		Entities.Pumpkin: plant_pumpkin,
		Entities.Sunflower: plant_sunflower
	}
	return table[entity]
	

