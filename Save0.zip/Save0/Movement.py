def noop():
	return

def move_to(x, y, protocol = noop):
	while get_pos_x() < x:
		protocol()
		move(East)
	while get_pos_x() > x:
		protocol()
		move(West)
	while get_pos_y() < y:
		protocol()
		move(North)
	while get_pos_y() > y:
		protocol()
		move(South)

# Mostly used for the Snake
def move_top(protocol = noop):
	x = get_pos_x()
	y = get_world_size() - 1
	move_to(x,y, protocol)
	
def move_bottom(protocol = noop):
	x = get_pos_x()
	y = 1
	move_to(x,y, protocol)

def move_right(protocol = noop):
	x = get_world_size() - 1
	y = get_pos_y()
	move_to(x,y, protocol)
	
def move_left(protocol = noop):
	x = 0
	y = get_pos_y()
	move_to(x,y, protocol)

# For Cactus
def move_item(x, y):
	while get_pos_x() < x:
		swap(East)
		move(East)
	while get_pos_x() > x:
		swap(West)
		move(West)
	while get_pos_y() < y:
		swap(North)
		move(North)
	while get_pos_y() > y:
		swap(South)
		move(South)