import Movement
import Mazes

directions = [North, East, South, West]
master_drone = False

def spawn(x, y):
	Movement.move_to(x,y)
	start_time = get_time()
	dir_index = 0
	
	while True:
		et = get_entity_type()
		if et == Entities.Grass and not master_drone:
			while et == Entities.Grass:
				et = get_entity_type()
		elif et == Entities.Grass and master_drone:
			plant(Entities.Bush)
			substance = get_world_size() * 2**(num_unlocked(Unlocks.Mazes) - 1)
			use_item(Items.Weird_Substance, substance)
			et = get_entity_type()
		
		if et == Entities.Treasure:
			harvest()
		
		while not can_move(directions[dir_index]):
			dir_index += 1
			if dir_index >= len(directions):
				dir_index = 0
		move(directions[dir_index]) 
		dir_index -= 1
		if dir_index == -1:
			dir_index = 3

clear()
for i in range(get_world_size()):
	if i != 0:
		spawn_drone(spawn, i, i)

master_drone = True
start_time = get_time()
while get_time() - start_time < 5:
	get_time()
spawn(0,0)