import Movement
import Planting

entity = Entities.Sunflower
instructions = Planting.get_instructions(entity)

def driver(x,y):
	Movement.move_to(x,y)
	while True:
		if can_harvest():
			harvest()
		instructions()
		move(North)

clear()
for x in range(1, 32):
	spawn_drone(driver, x, 0)
driver(0, 0)