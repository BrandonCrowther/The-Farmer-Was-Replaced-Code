items = {
	Items.Hay: 999999999999,
	Items.Wood: 999999999999,
	Items.Fertilizer: 999999999999,
	Items.Weird_Substance: 999999999999,
	Items.Water: 999999999999, 
}

simulate("Carrot_200_2", Unlocks, items, {}, 0, 10)