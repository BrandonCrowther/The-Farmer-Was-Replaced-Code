import Movement
import Mazes

def spawn(x, y, max_len, initializer = False):
	start_time = get_time()
	if initializer:
		Movement.move_to(x,y)
	else:
		Movement.move_to(x + 2, y + 2)
		
	while get_time() - start_time < 5:
		get_time()
	
	if initializer:
		Mazes.initialize_maze(max_len)
	else:
		start_time = get_time()
		while get_time() - start_time < 1:
			get_time()
	while True:
		result = Mazes.start_solving()
		if result:
			Mazes.harvest_treasure(max_len, x, y)

clear()
max_len = 8
for i in range(get_world_size() / max_len):
	for j in range(get_world_size() / max_len):
		if i + j != 0:
			start_coord_x = i * max_len + 4
			start_coord_y = j * max_len + 4
			spawn_drone(spawn, start_coord_x, start_coord_y, max_len, True)
			spawn_drone(spawn, start_coord_x, start_coord_y, max_len)
	
spawn_drone(spawn, 0, 0, max_len)
spawn(0,0, max_len, True)