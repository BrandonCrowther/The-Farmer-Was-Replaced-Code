def sort(stack, comparator):
	for index in range(len(stack)):
		lowest_index = index
		for c in range(index + 1, len(stack)):
			if comparator(stack[c], stack[lowest_index]):
				lowest_index = c
		tmp = stack[index]
		stack[index] = stack[lowest_index]
		stack[lowest_index] = tmp
	return stack

def sort_asc(stack):
	def comparator(a, b):
		return a < b
	return sort(stack, comparator)
	
def sort_desc(stack):
	def comparator(a, b):
		return a > b
	return sort(stack, comparator)
