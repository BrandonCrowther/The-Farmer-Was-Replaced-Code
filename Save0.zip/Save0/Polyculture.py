import Movement
import Planting

def polyculture(entity_type):
	x, y = get_pos_x(), get_pos_y()
	plant_type, (px, py) = get_companion()
	instructions = Planting.get_instructions(plant_type)
	Movement.move_to(px, py)
	harvest()
	instructions()
	Movement.move_to(x, y)