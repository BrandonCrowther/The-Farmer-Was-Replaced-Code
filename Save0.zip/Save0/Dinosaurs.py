import Movement

def is_finished():
	if can_move(North):
		return False
	elif can_move(East):
		return False
	elif can_move(South):
		return False
	elif can_move(West):
		return False
		
	return True
	
def movef(dir):
	move(dir)
	if is_finished():
		return True
	return False

def cycle():
	ws = get_world_size()
	change_hat(Hats.Brown_Hat)
	change_hat(Hats.Dinosaur_Hat)
	while not is_finished():
		while get_pos_y() < get_world_size() - 1:
			if movef(North):
				return True
		if movef(East):
			return True
		
		while get_pos_y() > 1:
			if movef(South):
				return True
		if movef(East):
			return True
		if(get_pos_x() == get_world_size() - 1 and get_pos_y() == 1):
			if movef(South):
				return True
			while get_pos_x() != 0:
				if movef(West):
					return True