import Dinosaurs
import Movement

def protocol():
	if can_move(North):
		return True
	elif can_move(East):
		return True
	elif can_move(South):
		return True
	elif can_move(West):
		return True
	else:
		change_hat(Hats.Brown_Hat)
		change_hat(Hats.Dinosaur_Hat)

def forward():
	while True:
		Movement.move_top(protocol)
		move(East)
		Movement.move_bottom(protocol)
		move(East)
		if(get_pos_x() == get_world_size() - 1 and get_pos_y() == 1):
			return
		
clear()
change_hat(Hats.Brown_Hat)
change_hat(Hats.Dinosaur_Hat)
while(True):
	forward()
	move(South)
	Movement.move_left(protocol)