import Await
import Movement
import Polyculture
import Planting

entity = Entities.Grass
instructions = Planting.get_instructions(entity)

def driver(x, y):
	Movement.move_to(x,y)
	instructions()
	while True:
		while get_water() < 0.75:
			use_item(Items.Water)
		Polyculture.polyculture(entity)
		Await.await_harvest()
		harvest()

clear()
for i in range(6):
	for j in range(6):
		spawn_drone(driver, 3 + i*5, 3 + j*5)
		