import Movement

opposite_directions = {
	North: South,
	South: North,
	East: West,
	West: East
}

coordinate_adjustments = {
	North: [0, 1],
	South: [0, -1],
	East: [1, 0],
	West: [-1, 0]
}


def harvest_treasure(maze_size, x, y):
	substance = maze_size * 2**(num_unlocked(Unlocks.Mazes) - 1)
	success = use_item(Items.Weird_Substance, substance)
	if not success:
		harvest()
		Movement.move_to(x,y)
		plant(Entities.Bush)
		harvest_treasure(maze_size, x, y)

def initialize_maze(maze_size):
	plant(Entities.Bush)
	harvest_treasure(maze_size, 0, 0)



def valid_moves(previous_move = None):
	ret = []
	moves = set((North, East, South, West))
	
	if get_entity_type() == Entities.Grass:
		return ret
	
	if previous_move != None:
		moves.remove(opposite_directions[previous_move])
	
	for m in set(moves):
		adj = coordinate_adjustments[m]
		px, py = get_pos_x(), get_pos_y() 
		x, y = px + adj[0], py + adj[1]
		
		if not can_move(m) or is_dead_end(x, y):
			moves.remove(m)
		else:
			meas = measure()
			if meas == None:
				return []
			tx, ty = meas[0], meas[1]
			distx = abs(tx - px)
			disty = abs(ty - py)
			cdistx = abs(tx - x)
			cdisty = abs(ty - y)
			if cdistx + cdisty < distx + disty:
				ret.insert(0, m)
			else:
				ret.append(m)
			
	return ret

dead_ends = []
def is_dead_end(x = get_pos_x(), y = get_pos_y()):
	for i in dead_ends:
		if i[0] == x and i[1] == y:
			return True
	return False


def backtrack(backstack):
	while(len(backstack) > 0):
		if get_entity_type() == Entities.Treasure:
			global dead_ends
			dead_ends = []
			return True
		move(backstack.pop())
	return False
		
treasure_location = None
def recurse(direction, backstack):

	meas = measure()
	global treasure_location
	if meas != treasure_location or treasure_location == None:
		treasure_location = meas
		global dead_ends
		dead_ends = []
				
	move(direction)
	backstack.append(opposite_directions[direction])

	entity = get_entity_type()
	
	if entity != Entities.Hedge and entity != Entities.Treasure:
		global dead_ends
		dead_ends = []
		return True
	
	if entity == Entities.Treasure:
		global dead_ends
		dead_ends = []
		return True
	
	moves = valid_moves(direction)
	move_len = len(moves)
	if move_len > 1:
		global dead_ends
		dead_ends.append([get_pos_x(), get_pos_y()])
	for m in moves:
		if m == opposite_directions[direction]:
			continue
		ret = recurse(m, [])
		if ret == True:
			return True
	
	bt = backtrack(backstack)
	backstack = []
	return bt
		

def start_solving():
	moves = valid_moves()
	for m in moves:
		ret = recurse(m, [])	
		if ret:
			return True
	return False