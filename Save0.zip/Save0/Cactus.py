import Movement
import Planting
import Sorting

def prep(entity, dir, instructions):
	sizes = []
	for i in range(get_world_size()):
		instructions()
		plant(entity)
		sizes.append(measure())
		move(dir)
	return sizes
	
def perform_sort(array, dir):
	for i in range(len(array)):
		target_number = array[i]
		m = measure()
		while m != target_number:
			move(dir)
			m = measure()
		if dir == North or dir == South:
			x = get_pos_x()
			Movement.move_item(x, i)
			if i + 1 < get_world_size():
				Movement.move_to(x, i + 1)
		else:
			y = get_pos_y()
			Movement.move_item(i, y)
			if i + 1 < get_world_size():
				Movement.move_to(i + 1, y)
		
				