def await_harvest():
	h = can_harvest()
	while not h:
		h = can_harvest()