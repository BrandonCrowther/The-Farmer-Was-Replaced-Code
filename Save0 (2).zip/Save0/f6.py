unlocks = Unlocks
items = {Items.Weird_Substance: 99999999}
globals = {}
seed = -1
speedup = 5000
simulate("f0", unlocks, items, globals, seed, speedup)