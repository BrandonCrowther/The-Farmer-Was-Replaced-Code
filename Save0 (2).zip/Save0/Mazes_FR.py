import Common
import Mazes

directions = [North, East, South, West]
def protocol(x = 0, y = 0):
	Common.move_to(x,y)
	start_time = get_time()
	dir_index = 0
	
	Common.get_planting_instructions(Entities.Bush)()
	substance = get_world_size() * 2**(num_unlocked(Unlocks.Mazes) - 1)
	use_item(Items.Weird_Substance, substance)
	if get_entity_type() == Entities.Treasure:
		harvest()
		return True
	while True:
		while not can_move(directions[dir_index]):
			if get_entity_type() == Entities.Treasure:
				harvest()
				return True
			dir_index += 1
			if dir_index >= len(directions):
				dir_index = 0
		move(directions[dir_index]) 
		dir_index -= 1
		if dir_index == -1:
			dir_index = 3