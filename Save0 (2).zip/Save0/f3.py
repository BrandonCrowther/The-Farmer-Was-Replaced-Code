unlocks = Unlocks
items = {Items.Cactus: 99999999}
globals = {}
seed = -1
speedup = 50
simulate("Dino_Achievement", unlocks, items, globals, seed, speedup)